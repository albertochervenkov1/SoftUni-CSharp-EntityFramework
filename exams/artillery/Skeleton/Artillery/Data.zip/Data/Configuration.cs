﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-3VRUKPL\SQLEXPRESS;Database=Artillery;Trusted_Connection=True";
    }
}
