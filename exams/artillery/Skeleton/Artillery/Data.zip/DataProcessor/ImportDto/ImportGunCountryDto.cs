﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace Artillery.DataProcessor.ImportDto
{
    [JsonObject]
    public class ImportGunCountryDto
    {
        
        public int Id { get; set; }
    }
}
