﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-3VRUKPL\SQLEXPRESS;Database=BookShop;Trusted_Connection=True";
    }
}