﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace CarDealer.DTO.Car
{
    [JsonObject]
    public class ExportCarWithListParts
    {

    }
}
