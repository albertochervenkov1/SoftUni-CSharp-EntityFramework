﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data
{
    public  static class Configuration
    {
        public static string ConnectionName= @"SERVER=DESKTOP-3VRUKPL\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;";
    }
}
